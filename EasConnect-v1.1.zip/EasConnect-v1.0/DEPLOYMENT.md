# Deployment path
1. Create a VPS/cloud server.
2. Copy `server/`.
3. Create `.env` from `.env.example` and set a strong JWT_SECRET.
4. `docker compose up -d --build`
5. Put an HTTPS reverse proxy in front of port 8080.
6. Point Android API/WebSocket URLs at the HTTPS domain.
7. Test with two Android devices.
8. Add push notifications and WebRTC calling.

Do not expose the development server without HTTPS or a production secret.
