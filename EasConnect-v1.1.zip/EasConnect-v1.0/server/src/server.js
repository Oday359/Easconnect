
const http=require('http'), express=require('express'), jwt=require('jsonwebtoken');
const bcrypt=require('bcryptjs'), Database=require('better-sqlite3');
const {WebSocketServer}=require('ws');
const app=express(), PORT=process.env.PORT||8080;
const SECRET=process.env.JWT_SECRET||'CHANGE_ME';
const db=new Database(process.env.DB_PATH||'easconnect.db');
db.pragma('journal_mode=WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,display_name TEXT NOT NULL,avatar_url TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY AUTOINCREMENT,user_a INTEGER NOT NULL,user_b INTEGER NOT NULL,created_at TEXT NOT NULL,UNIQUE(user_a,user_b));
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,conversation_id INTEGER NOT NULL,sender_id INTEGER NOT NULL,body TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'sent',created_at TEXT NOT NULL);
`);
app.use(express.json({limit:'5mb'}));
const now=()=>new Date().toISOString();
const publicUser=u=>({id:u.id,username:u.username,displayName:u.display_name||u.displayName,avatarUrl:u.avatar_url||u.avatarUrl||null});
const sign=u=>jwt.sign({id:u.id,username:u.username},SECRET,{expiresIn:'30d'});
function auth(req,res,next){try{const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))throw 0;req.user=jwt.verify(h.slice(7),SECRET);next()}catch{res.status(401).json({error:'Authentication required'})}}
app.get('/health',(q,s)=>s.json({ok:true,name:'EasConnect',version:'1.1.0'}));
app.post('/api/register',async(req,res)=>{
 const {username,password,displayName}=req.body||{};
 if(!username||!password||!displayName)return res.status(400).json({error:'Missing fields'});
 if(String(username).length<3||String(password).length<6)return res.status(400).json({error:'Username 3+ and password 6+'});
 try{const h=await bcrypt.hash(password,12), n=String(username).trim().toLowerCase(), d=String(displayName).trim();
  const r=db.prepare('INSERT INTO users(username,password_hash,display_name,created_at) VALUES(?,?,?,?)').run(n,h,d,now());
  const u=db.prepare('SELECT * FROM users WHERE id=?').get(r.lastInsertRowid);res.json({user:publicUser(u),token:sign(u)});
 }catch(e){res.status(String(e).includes('UNIQUE')?409:500).json({error:String(e).includes('UNIQUE')?'Username already exists':'Registration failed'})}
});
app.post('/api/login',async(req,res)=>{
 const u=db.prepare('SELECT * FROM users WHERE username=?').get(String(req.body?.username||'').trim().toLowerCase());
 if(!u||!(await bcrypt.compare(String(req.body?.password||''),u.password_hash)))return res.status(401).json({error:'Incorrect username or password'});
 res.json({user:publicUser(u),token:sign(u)});
});
app.get('/api/me',auth,(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);res.json({user:publicUser(u)})});
app.get('/api/users',auth,(req,res)=>{const q=String(req.query.q||'').trim().toLowerCase();if(!q)return res.json({users:[]});
 res.json({users:db.prepare("SELECT id,username,display_name AS displayName,avatar_url AS avatarUrl FROM users WHERE id<>? AND (username LIKE ? OR display_name LIKE ?) LIMIT 30").all(req.user.id,`%${q}%`,`%${q}%`)})});
app.post('/api/conversations',auth,(req,res)=>{
 const other=Number(req.body?.userId);if(!other||other===req.user.id)return res.status(400).json({error:'Invalid user'});
 const a=Math.min(req.user.id,other),b=Math.max(req.user.id,other);
 db.prepare('INSERT OR IGNORE INTO conversations(user_a,user_b,created_at) VALUES(?,?,?)').run(a,b,now());
 res.json({conversation:db.prepare('SELECT * FROM conversations WHERE user_a=? AND user_b=?').get(a,b)});
});
app.get('/api/conversations',auth,(req,res)=>{
 const cs=db.prepare(`SELECT c.id,c.user_a AS userA,c.user_b AS userB,u.id AS otherId,u.username,u.display_name AS displayName
 FROM conversations c JOIN users u ON u.id=CASE WHEN c.user_a=? THEN c.user_b ELSE c.user_a END
 WHERE c.user_a=? OR c.user_b=? ORDER BY c.id DESC`).all(req.user.id,req.user.id,req.user.id);
 res.json({conversations:cs});
});
app.get('/api/conversations/:id/messages',auth,(req,res)=>{
 const id=Number(req.params.id),c=db.prepare('SELECT * FROM conversations WHERE id=? AND (user_a=? OR user_b=?)').get(id,req.user.id,req.user.id);
 if(!c)return res.status(404).json({error:'Conversation not found'});
 const ms=db.prepare('SELECT id,sender_id AS senderId,body,status,created_at AS createdAt FROM messages WHERE conversation_id=? ORDER BY id ASC LIMIT 500').all(id);
 db.prepare("UPDATE messages SET status='read' WHERE conversation_id=? AND sender_id<>?").run(id,req.user.id);
 res.json({messages:ms});
});

const server=http.createServer(app), wss=new WebSocketServer({server}), sockets=new Map();
function emit(uid,p){const set=sockets.get(Number(uid));if(set)for(const ws of set)if(ws.readyState===1)ws.send(JSON.stringify(p))}
wss.on('connection',(ws,req)=>{
 try{
  const t=new URL(req.url,'http://x').searchParams.get('token'),u=jwt.verify(t,SECRET),uid=Number(u.id);
  if(!sockets.has(uid))sockets.set(uid,new Set());sockets.get(uid).add(ws);
  ws.send(JSON.stringify({type:'connected',userId:uid}));
  ws.on('message',raw=>{
   try{const d=JSON.parse(raw.toString());if(d.type!=='message')return;
    const cid=Number(d.conversationId),body=String(d.body||'').trim();if(!body||body.length>4000)return;
    const c=db.prepare('SELECT * FROM conversations WHERE id=? AND (user_a=? OR user_b=?)').get(cid,uid,uid);if(!c)return;
    const to=c.user_a===uid?c.user_b:c.user_a, status=sockets.has(to)?'delivered':'sent',createdAt=now();
    const r=db.prepare('INSERT INTO messages(conversation_id,sender_id,body,status,created_at) VALUES(?,?,?,?,?)').run(cid,uid,body,status,createdAt);
    const m={id:r.lastInsertRowid,conversationId:cid,senderId:uid,body,status,createdAt};emit(uid,{type:'message',message:m});emit(to,{type:'message',message:m});
   }catch{}
  });
  ws.on('close',()=>{const set=sockets.get(uid);if(set){set.delete(ws);if(!set.size)sockets.delete(uid)}})
 }catch{ws.close(1008,'Invalid token')}
});
server.listen(PORT,()=>console.log('EasConnect v1 server on '+PORT));
