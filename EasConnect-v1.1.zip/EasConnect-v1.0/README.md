# EasConnect v1.1

Core Android + Node backend integration milestone.

## Android
- Login/register calls the backend.
- Contacts search real users.
- Chat creates/opens real conversations.
- Chat loads persistent message history.
- WebSocket messaging is supported.

### Server URL
Edit `android/app/src/main/java/com/easconnect/app/MainActivity.kt` and change `BASE_URL`. For an Android emulator using a server on the same computer, `http://10.0.2.2:8080` is the usual address. A physical phone needs the server's reachable LAN/public address.

## Server
Run `npm install` then `JWT_SECRET=your-long-random-secret npm start`. The server stores data in SQLite.

This milestone is for testing; production still needs HTTPS/WSS, secure secret management, push notifications, media storage, rate limiting, abuse controls, backups, and security review.
