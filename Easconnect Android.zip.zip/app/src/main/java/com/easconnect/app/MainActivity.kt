package com.easconnect.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.plugins.websocket.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.websocket.*
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

private const val BASE_URL = "http://10.0.2.2:8080"
private const val WS_URL = "ws://10.0.2.2:8080"

@Serializable data class User(val id:Int, val username:String, val displayName:String, val avatarUrl:String?=null)
@Serializable data class AuthResponse(val user:User, val token:String)
@Serializable data class LoginBody(val username:String,val password:String)
@Serializable data class RegisterBody(val username:String,val password:String,val displayName:String)
@Serializable data class UserList(val users:List<User>)
@Serializable data class Conversation(val id:Int,val userA:Int,val userB:Int,val otherId:Int,val username:String,val displayName:String)
@Serializable data class ConversationList(val conversations:List<Conversation>)
@Serializable data class CreateConversationBody(val userId:Int)
@Serializable data class Message(val id:Long,val conversationId:Int,val senderId:Int,val body:String,val status:String,val createdAt:String)
@Serializable data class MessageList(val messages:List<Message>)
@Serializable data class WsEnvelope(val type:String,val message:Message?=null,val userId:Int?=null)
@Serializable data class WsMessage(val type:String,val conversationId:Int,val body:String)

class EasApi {
    private val client=HttpClient { install(ContentNegotiation){json(Json{ignoreUnknownKeys=true})}; install(WebSockets) }
    var token:String?=null
    suspend fun login(u:String,p:String)=client.post("$BASE_URL/api/login"){contentType(ContentType.Application.Json);setBody(LoginBody(u,p))}.body<AuthResponse>().also{token=it.token}
    suspend fun register(u:String,p:String,d:String)=client.post("$BASE_URL/api/register"){contentType(ContentType.Application.Json);setBody(RegisterBody(u,p,d))}.body<AuthResponse>().also{token=it.token}
    private fun HttpRequestBuilder.auth(){header(HttpHeaders.Authorization,"Bearer ${token}")}
    suspend fun users(q:String)=client.get("$BASE_URL/api/users"){auth();parameter("q",q)}.body<UserList>().users
    suspend fun conversations()=client.get("$BASE_URL/api/conversations"){auth()}.body<ConversationList>().conversations
    suspend fun createConversation(id:Int)=client.post("$BASE_URL/api/conversations"){auth();contentType(ContentType.Application.Json);setBody(CreateConversationBody(id))}.body<Conversation>().id
    suspend fun messages(id:Int)=client.get("$BASE_URL/api/conversations/$id/messages"){auth()}.body<MessageList>().messages
    suspend fun socket(onMessage:(Message)->Unit)=client.webSocket("$WS_URL/ws?token=$token") { for(frame in incoming) if(frame is Frame.Text){val e=Json.decodeFromString<WsEnvelope>(frame.readText());e.message?.let(onMessage)} }
    suspend fun send(ws:DefaultClientWebSocketSession,cid:Int,body:String){ws.send(Json.encodeToString(WsMessage.serializer(),WsMessage("message",cid,body)))}
}

class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle){super.onCreate(b);setContent{EasConnectApp()}} }

@Composable fun EasConnectApp(){
 val nav=rememberNavController(); val api=remember{EasApi()}; val scope=rememberCoroutineScope(); var me by remember{mutableStateOf<User?>(null)}
 NavHost(navController=nav,startDestination="login"){
  composable("login"){Login(api){u->me=u;nav.navigate("home"){popUpTo("login"){inclusive=true}}}}
  composable("home"){Home(nav,api,me!!)}
  composable("chat/{id}/{name}"){b->Chat(b.arguments?.getString("id")!!.toInt(),b.arguments?.getString("name")?:("Chat"),api,me!!.id)}
 }
}

@Composable fun Login(api:EasApi,onDone:(User)->Unit){
 var username by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var display by remember{mutableStateOf("")};var register by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};val scope=rememberCoroutineScope()
 Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center){
  Text("EasConnect",style=MaterialTheme.typography.displaySmall);Text(if(register)"Create your account" else "Connect simply.")
  Spacer(Modifier.height(20.dp));if(register)OutlinedTextField(display,{display=it},label={Text("Display name")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(username,{username=it},label={Text("Username")},modifier=Modifier.fillMaxWidth());OutlinedTextField(password,{password=it},label={Text("Password")},modifier=Modifier.fillMaxWidth())
  if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
  Spacer(Modifier.height(12.dp));Button(enabled=!busy,onClick={scope.launch{busy=true;error="";runCatching{if(register)api.register(username,password,display) else api.login(username,password)}.onSuccess{onDone(it.user)}.onFailure{error=it.message?:"Connection failed"};busy=false}},modifier=Modifier.fillMaxWidth()){Text(if(busy)"Please wait…" else if(register)"Create account" else "Log in")}
  TextButton(onClick={register=!register;error=""}){Text(if(register)"Already have an account? Log in" else "Create a new account")}
 }
}

@Composable fun Home(nav:NavHostController,api:EasApi,me:User){
 var tab by remember{mutableStateOf(0)};var conversations by remember{mutableStateOf(emptyList<Conversation>())};var query by remember{mutableStateOf("")};var results by remember{mutableStateOf(emptyList<User>())};var error by remember{mutableStateOf("")};val scope=rememberCoroutineScope()
 LaunchedEffect(Unit){runCatching{conversations=api.conversations()}.onFailure{error=it.message?:"Unable to load chats"}}
 Scaffold(bottomBar={NavigationBar{listOf("Chats","Calls","Contacts","Profile").forEachIndexed{i,t->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(Icons.Default.Person,null)},label={Text(t)})}}}){pad->Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()){
  Text(listOf("Chats","Calls","Contacts","Profile")[tab],style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp))
  when(tab){0->if(conversations.isEmpty())Text(if(error.isBlank())"No conversations yet. Open Contacts to find someone." else error) else LazyColumn{items(conversations){c->ListItem(headlineContent={Text(c.displayName)},supportingContent={Text("@${c.username}")},leadingContent={Icon(Icons.Default.Chat,null)},modifier=Modifier.fillMaxWidth().clickable{nav.navigate("chat/${c.id}/${c.displayName}")},trailingContent={Text("Open")})}}}
   1->Text("Voice and video calls will be connected after messaging.")
   2->{Row{OutlinedTextField(query,{query=it},label={Text("Search people")},modifier=Modifier.weight(1f));Spacer(Modifier.width(8.dp));Button(onClick={scope.launch{results=runCatching{api.users(query)}.getOrDefault(emptyList())}}){Text("Search")}};Spacer(Modifier.height(12.dp));LazyColumn{items(results){u->ListItem(headlineContent={Text(u.displayName)},supportingContent={Text("@${u.username}")},modifier=Modifier.fillMaxWidth(),trailingContent={Button(onClick={scope.launch{val id=api.createConversation(u.id);conversations=api.conversations();nav.navigate("chat/$id/${u.displayName}")}}){Text("Chat")}})}}}
   3->Text("Signed in as @${me.username}\n\nProfile settings will be added next.")
  }
 }}
}

@Composable fun Chat(id:Int,name:String,api:EasApi,myId:Int){
 var text by remember{mutableStateOf("")};var messages by remember{mutableStateOf(emptyList<Message>())};var error by remember{mutableStateOf("")};val scope=rememberCoroutineScope();var socket by remember{mutableStateOf<DefaultClientWebSocketSession?>(null)}
 LaunchedEffect(id){messages=runCatching{api.messages(id)}.getOrDefault(emptyList());launch{runCatching{api.socket{m->if(m.conversationId==id)messages=messages+m}}.onFailure{error="Live connection unavailable; refresh chat later."}}}
 Scaffold(topBar={TopAppBar(title={Text(name)})}){p->Column(Modifier.padding(p).fillMaxSize()){
  if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(8.dp));LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp)){items(messages){m->Text((if(m.senderId==myId)"You: " else "$name: ")+m.body,Modifier.padding(8.dp))}}
  Row(Modifier.padding(8.dp)){OutlinedTextField(text,{text=it},modifier=Modifier.weight(1f),placeholder={Text("Message")});Button(enabled=text.isNotBlank(),onClick={val body=text;scope.launch{runCatching{val wsClient=HttpClient{install(WebSockets)};wsClient.webSocket("$WS_URL/ws?token=${api.token}"){send(Json.encodeToString(WsMessage.serializer(),WsMessage("message",id,body)))};messages=api.messages(id);text=""}.onFailure{error="Message failed: ${it.message}"}}}){Text("Send")}}
 }}
}
